# -*- coding: utf-8 -*-

'''
    homelander Add-on
'''

from sys import argv
from resources.lib.modules import router
router.routing(argv[2])
