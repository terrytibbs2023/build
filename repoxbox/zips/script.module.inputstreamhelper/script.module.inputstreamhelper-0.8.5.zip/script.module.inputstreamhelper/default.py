# -*- coding: utf-8 -*-
''' This is the actual InputStream Helper API script entry point '''

import sys
from lib.inputstreamhelper.api import run

run(sys.argv)
