# plugin.video.tmdb.bingie.helper

TMDb Helper for Bingie skin.
