import xbmc

# Run silently on boot
xbmc.executebuiltin('RunPlugin("plugin://plugin.video.fenlight/?mode=clear_cache&cache=trakt")')

