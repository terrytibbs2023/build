import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://githubraw.com/terrytibbs2023/build/main/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://githubraw.com/terrytibbs2023/build/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
