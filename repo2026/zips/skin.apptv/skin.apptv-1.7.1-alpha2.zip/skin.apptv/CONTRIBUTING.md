## Contribute To AppTV Kodi skin

Community made patches, localizations, bug reports and contributions are always welcome!

__Please Note:__ I do NOT watch GitHub that closely, so bug reports, feature requests and general support questions are best handled via the Kodi forums.  The skin specific sub forum is located at:
(https://forum.kodi.tv/forumdisplay.php?fid=76)

Contibuter access will only be granted after you have made an approach via the forum listed above.

Thanks for your understanding
Wyrm